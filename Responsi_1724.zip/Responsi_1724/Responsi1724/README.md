# Mail LogIn

## Here are App UI snapshots 🤎

<b> Functionality & Concepts used : </b>

- I have intregrated Google's Firebase for authentication of users on server side 🤓

- Users can sign-up in app using email address and password 🤓

- After signing up users get mail on their registered email address for sake of authentication 🤓


### These are Login and SignUp Activities UI
<img width="200" alt="sampleimages" src="https://raw.githubusercontent.com/ambasta-shalu/mail-login/master/App-Snapshot/snapshot1.jpeg"> <img width="200" 
alt="sampleimages" src="https://raw.githubusercontent.com/ambasta-shalu/mail-login/master/App-Snapshot/snapshot2.jpeg"> <img width="200" 
alt="sampleimages" src="https://raw.githubusercontent.com/ambasta-shalu/mail-login/master/App-Snapshot/snapshot3.jpeg">


### This is Main Activity UI
<img width="200" alt="sampleimages" src="https://raw.githubusercontent.com/ambasta-shalu/mail-login/master/App-Snapshot/snapshot4.jpeg"> <img width="200" 
alt="sampleimages" src="https://raw.githubusercontent.com/ambasta-shalu/mail-login/master/App-Snapshot/snapshot5.jpeg">
