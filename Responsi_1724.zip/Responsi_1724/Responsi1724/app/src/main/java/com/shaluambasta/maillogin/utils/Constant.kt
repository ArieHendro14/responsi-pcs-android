package com.shaluambasta.maillogin.utils

const val Name = "NameOfUserLogged"
